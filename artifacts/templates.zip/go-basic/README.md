# {{.ProjectName}}

Generated with projectgen.