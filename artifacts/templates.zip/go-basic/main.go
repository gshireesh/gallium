package main

import "fmt"

func main() {
	fmt.Println("Hello from {{.projectName}} {{.projectDescription}}!")
}
