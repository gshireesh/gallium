#!/bin/bash
echo "[PRE] Setting up project..."
echo "[PRE] Creating directories..."